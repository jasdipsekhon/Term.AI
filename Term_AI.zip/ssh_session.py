import pyte
import asyncio
import codecs
from ssh_client import SSHClient


class _TrackedHistoryScreen(pyte.HistoryScreen):
    # pyte discards history.top on a scrollback clear so we need to track the # of lines produced/discarded
    def __init__(self, *args, **kwargs):
        self.lines_produced = 0
        self.lines_discarded = 0
        super().__init__(*args, **kwargs)

    def index(self):
        self.lines_produced += 1
        super().index()

    def _reset_history(self):
        self.lines_discarded = self.lines_produced
        super()._reset_history()

    def resize(self, lines=None, columns=None):
        # Shrinking drops rows from the top of the buffer (screens.py Screen.resize)
        # without going through index()/history, so bank the same way as a reset.
        target_lines = lines or self.lines
        if target_lines < self.lines:
            self.lines_discarded += self.lines - target_lines
        super().resize(lines, columns)
        self.cursor.y = min(self.cursor.y, self.lines - 1)


class SSHSession:
    def __init__(self, host, username, password, cols=80, rows=24):
        self.host = host
        self.username = username
        self.password = password
        self.cols = cols
        self.rows = rows
        self.ssh_client = None
        self.screen = _TrackedHistoryScreen(cols, rows, history=10000)  # deque of lines; each line is a dict of column_index -> Char
        self.stream = pyte.Stream(self.screen)  # parses raw bytes and updates screen
        self.subscribers = set()  # synchronous callbacks for SSH output, one per connected client
        self.decoder = codecs.getincrementaldecoder("utf-8")(errors="replace") # incremental decoder for UTF-8 bytes to string, replacing invalid sequences with U+FFFD
        self.last_read_line = 0  # line_count() as of the end of the last write_and_read_response call

    def _on_data(self, data):
        self.stream.feed(self.decoder.decode(data))
        self._notify_subscriber(data)

    async def start_ssh_client(self):
        self.ssh_client = SSHClient(self.host, self.username, self.password, self._on_data)
        await self.ssh_client.connect()

    async def resize(self, width, height):
        self.cols = width
        self.rows = height
        self.screen.resize(height, width)
        if self.ssh_client:
            await self.ssh_client.resize(width, height)

    async def write(self, data):
        if self.ssh_client:
            await self.ssh_client.send_command(data)

    async def close(self):
        if self.ssh_client:
            await self.ssh_client.close()

    # ── Pyte interface ──────────────────────────────────────────────────

    def line_count(self):
        return self.screen.lines_produced

    def convert_screen_list_to_string(self):
        return "\n".join(self.screen.display)

    def get_screen_snapshot(self):
        # Redraw the current visible screen for a browser that's just connecting to
        # an already-running session, which otherwise only sees output from this point on.
        text = "\r\n".join(line.rstrip() for line in self.screen.display)
        cursor_y = self.screen.cursor.y
        cursor_x = self.screen.cursor.x
        return f"\x1b[3J\x1b[2J\x1b[H{text}\x1b[{cursor_y + 1};{cursor_x + 1}H".encode()
    
    async def wait_until_idle(self, timeout_s=30, idle_s=0.3):
        idle = False
        current_event_loop = asyncio.get_running_loop()
        start_time = current_event_loop.time()
        time_of_change = start_time
        last_string = self.convert_screen_list_to_string()
        while current_event_loop.time() - start_time < timeout_s:
            await asyncio.sleep(0.05)
            current_string = self.convert_screen_list_to_string()
            if current_string != last_string:
                last_string = current_string
                time_of_change = current_event_loop.time()
            if current_event_loop.time() - time_of_change >= idle_s:
                idle = True
                return {"done": idle}
        return {"done": idle, "reason": "Timeout reached before idle state."}

    def get_output_since(self, start_line):
        history = []
        for line_key in self.screen.history.top:
            row = ""
            for col in range(self.cols):
                if col in line_key:
                    row += line_key[col].data
                else:
                    row += " "
            row = row.rstrip()
            history.append(row)
        visible = []
        for row in self.screen.display:
            row = row.rstrip()
            visible.append(row)
        whole_screen = history + visible
        local_start = max(0, start_line - self.screen.lines_discarded)
        lines_after_start = whole_screen[local_start:]
        while lines_after_start and not lines_after_start[-1]:
            lines_after_start.pop()
        return "\n".join(lines_after_start)


    # ── WebSocket interface ──────────────────────────────────────────────────

    def subscribe(self, subscriber):
        self.subscribers.add(subscriber)

    def unsubscribe(self, subscriber):
        self.subscribers.discard(subscriber)

    def _notify_subscriber(self, data):
        for subscriber in self.subscribers:
            subscriber(data)
